package com.cg.exception;

public class BillUserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3988321974499263426L;

	public BillUserException() {
		}

	public BillUserException(String arg0) {
		super(arg0);
			}

	public BillUserException(Throwable arg0) {
		super(arg0);
	}

	public BillUserException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public BillUserException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

}
