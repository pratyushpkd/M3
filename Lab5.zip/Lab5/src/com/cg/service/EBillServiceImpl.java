package com.cg.service;

import com.cg.dao.EBillDAOImpl;
import com.cg.dao.IEBillDAO;
import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public class EBillServiceImpl implements IBillService {
	private IEBillDAO ebillDAO;
	
	public EBillServiceImpl() {
		super();
		ebillDAO = new EBillDAOImpl();
	}

	@Override
	public String insert(BillDTO billDTO) throws BillUserException {
		String name = null;
		
		boolean isInserted = ebillDAO.insert(billDTO);
		if(isInserted){
			name = ebillDAO.getConsName(billDTO.getConsumerNum());
		}
		else{
			throw new BillUserException("Record couldn't be inserted");
		}
		return name;
	}

}
