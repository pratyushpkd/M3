package com.capgemini.dto;

import java.sql.Date;

public class BillDTO {
	private int billNum;
	private int consumerNum;
	private double currentReading;
	private double unitsConsumed;
	private double netAmount;
	private Date billDate;
	
	public BillDTO() {
		super();
	}

	public BillDTO(int consumerNum, double currentReading,
			double unitsConsumed, double netAmount) {
		super();
		this.consumerNum = consumerNum;
		this.currentReading = currentReading;
		this.unitsConsumed = unitsConsumed;
		this.netAmount = netAmount;
	}

	public int getConsumerNum() {
		return consumerNum;
	}

	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}

	public double getCurrentReading() {
		return currentReading;
	}

	public void setCurrentReading(double currentReading) {
		this.currentReading = currentReading;
	}

	public double getUnitsConsumed() {
		return unitsConsumed;
	}

	public void setUnitsConsumed(double unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public Date getBillDate() {
		return billDate;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	public int getBillNum() {
		return billNum;
	}

	@Override
	public String toString() {
		return "BillDTO [billNum=" + billNum + ", consumerNum=" + consumerNum
				+ ", currentReading=" + currentReading + ", unitsConsumed="
				+ unitsConsumed + ", netAmount=" + netAmount + ", billDate="
				+ billDate + "]";
	}
	
	
}
