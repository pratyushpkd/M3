package com.capgemini.exception;

public class BillUserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4590697998120745691L;

	public BillUserException() {
		
	}

	public BillUserException(String message) {
		super(message);
		
	}

	public BillUserException(Throwable cause) {
		super(cause);
		
	}

	public BillUserException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public BillUserException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

}
