package com.capgemini.dao;

import com.capgemini.dto.BillDTO;
import com.capgemini.exception.BillUserException;

public interface IEBillDAO {
	public boolean insert(BillDTO billDTO)throws BillUserException;
	
	public String getConsName(int consumerNo)throws BillUserException;

}
