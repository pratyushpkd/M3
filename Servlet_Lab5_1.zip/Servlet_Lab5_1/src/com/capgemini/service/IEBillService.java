package com.capgemini.service;

import com.capgemini.dto.BillDTO;
import com.capgemini.exception.BillUserException;

public interface IEBillService {
	public String insert(BillDTO billDTO) throws BillUserException;
	
	

}
