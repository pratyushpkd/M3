package com.student.dao;

public interface QuerryMapper {
	
	public static final String viewAll="SELECT student_roll, studentname, dob from student_tbl";

}
