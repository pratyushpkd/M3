package com.student.exception;

public class StudentException extends Exception {

	public StudentException() {
		super();
		
	}

	public StudentException(String message) {
		super(message);
		
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 7278636172281449945L;

}
